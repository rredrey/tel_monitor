# config.py

# Настройки Solana RPC
SOLANA_RPC_URL = "https://api.mainnet-beta.solana.com"

# Telegram API
API_ID = "29281739"
API_HASH = "44c9b40fa8c0fb4594ffcf039e1e90ac"

# Имя Telegram-канала для мониторинга сигналов
TELEGRAM_CHANNEL = "MarkDegen"

# Приватный ключ кошелька (замените на реальный ключ для работы в реальном режиме)
PRIVATE_KEY = [76, 165, 72, 224, 33, 9, 232, 188, 179, 50, 169, 16, 244, 135, 119, 58, 199, 172, 141, 239, 53, 16, 149, 154, 74, 83, 136, 211, 27, 10, 245, 151, 131, 145, 15, 125, 55, 50, 135, 137, 206, 194, 69, 115, 69, 177, 221, 182, 13, 22, 64, 133, 57, 80, 255, 42, 24, 220, 68, 67, 15, 127, 69, 112]

# Режим работы (True - демо, False - реальный)
DEMO_MODE = True

# Токен бота для отправки уведомлений
BOT_TOKEN = "YOUR_TELEGRAM_BOT_TOKEN"

# ID чата для отправки уведомлений
NOTIFICATION_CHAT_ID = "YOUR_NOTIFICATION_CHAT_ID"
