# trading/utils.py
def check_balance(wallet):
    # Логика проверки баланса
    return 10.0
