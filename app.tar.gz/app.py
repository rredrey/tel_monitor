# app.py
import tkinter as tk
from tkinter import ttk, messagebox
import threading
import queue
import asyncio
import logging
from telethon import TelegramClient, events

# Импортируем остальные ваши модули
from config import load_config
from gui.main_tab import MainTab
from gui.settings_tab import SettingsTab
from gui.portfolio_tab import PortfolioTab
from trading.swap import swap_tokens # Предполагаем, что эта функция выполняет своп
from trading.wallet import DEMO_WALLET, get_wallet_balance # Пример
from trading.monitor import profit_monitoring_task # Импортируем задачу
from parser import parse_message # Пример

# Настройка логирования (можно вынести в отдельный модуль)
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s - %(levelname)s - %(message)s',
                    handlers=[logging.FileHandler("trading_bot.log"),
                              logging.StreamHandler()])

class TradingBotApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Telegram Crypto Trading Bot")
        self.root.protocol("WM_DELETE_WINDOW", self.on_closing) # Обработка закрытия окна

        self.config = load_config()
        self.gui_queue = queue.Queue() # Очередь для сообщений в GUI поток

        # --- Asyncio/Telethon Setup ---
        self.asyncio_loop = asyncio.new_event_loop()
        self.telethon_client = None
        self.telegram_thread = None
        self.telegram_monitoring_active = False

        # --- Profit Monitoring Setup ---
        self.profit_monitor_thread = None
        self.profit_monitor_stop_event = threading.Event()
        self.profit_monitoring_active = False

        # --- Trading Lock ---
        # Блокировка, чтобы избежать одновременного запуска нескольких свопов (если нужно)
        self.swap_lock = threading.Lock() 

        # --- GUI Setup ---
        self.notebook = ttk.Notebook(root)

        self.main_tab = MainTab(self.notebook, self)
        self.settings_tab = SettingsTab(self.notebook, self)
        self.portfolio_tab = PortfolioTab(self.notebook, self)

        self.notebook.add(self.main_tab, text='Основная')
        self.notebook.add(self.settings_tab, text='Настройки')
        self.notebook.add(self.portfolio_tab, text='Портфель')
        self.notebook.pack(expand=1, fill='both')

        # Запуск обработки очереди GUI
        self.process_gui_queue()

        # Запуск потока для asyncio
        self.start_asyncio_loop_thread()

        logging.info("Приложение инициализировано.")
        self.log_to_gui("Приложение запущено.")

        # Опционально: автоматический запуск мониторинга при старте
        # self.start_telegram_monitoring()
        # self.start_profit_monitoring()
        # self.update_portfolio_display() # Первоначальное отображение портфеля

    def start_asyncio_loop_thread(self):
        """Запускает цикл asyncio в отдельном потоке."""
        def loop_runner(loop):
            asyncio.set_event_loop(loop)
            try:
                loop.run_forever()
            finally:
                # Очистка при завершении цикла
                loop.run_until_complete(loop.shutdown_asyncgens())
                loop.close()
                logging.info("Asyncio loop остановлен.")

        self.telegram_thread = threading.Thread(target=loop_runner, args=(self.asyncio_loop,), daemon=True)
        self.telegram_thread.start()
        logging.info("Поток для asyncio запущен.")

    def run_async_task(self, coro):
        """Безопасно запускает корутину в цикле asyncio из другого потока."""
        if self.asyncio_loop.is_running():
            return asyncio.run_coroutine_threadsafe(coro, self.asyncio_loop)
        else:
            logging.error("Цикл Asyncio не запущен. Невозможно выполнить задачу.")
            return None

    def start_telegram_monitoring(self):
        """Запускает мониторинг Telegram."""
        if self.telegram_monitoring_active:
            self.log_to_gui("Мониторинг Telegram уже запущен.")
            return

        api_id = self.config['telegram']['api_id']
        api_hash = self.config['telegram']['api_hash']
        channel = self.config['telegram']['channel_username']

        if not api_id or not api_hash or not channel:
            self.log_to_gui("Ошибка: Не заданы API ID, API Hash или канал в config.py")
            messagebox.showerror("Ошибка конфигурации", "Не заданы API ID, API Hash или канал в config.py")
            return

        async def _start_client():
            try:
                self.telethon_client = TelegramClient('trading_session', api_id, api_hash, loop=self.asyncio_loop)
                await self.telethon_client.connect()
                if not await self.telethon_client.is_user_authorized():
                    # Сюда можно добавить логику запроса кода авторизации,
                    # но для GUI это сложно. Проще авторизоваться заранее
                    # через консольный скрипт telethon.
                    self.log_to_gui("Ошибка: Клиент не авторизован. Авторизуйтесь через консоль.")
                    await self.telethon_client.disconnect()
                    self.telethon_client = None
                    self.put_message_in_queue(('log', "Ошибка: Клиент не авторизован.")) # Обновление GUI
                    return

                self.log_to_gui(f"Подключено к Telegram. Начинаю мониторинг канала: {channel}")
                self.telegram_monitoring_active = True
                self.put_message_in_queue(('set_monitoring_status', True)) # Обновление кнопки GUI

                # Добавление обработчика сообщений
                self.telethon_client.add_event_handler(
                    self._handle_telegram_message,
                    events.NewMessage(chats=channel)
                )
                logging.info(f"Мониторинг Telegram канала '{channel}' запущен.")

            except Exception as e:
                logging.exception("Ошибка при запуске Telegram клиента:")
                self.log_to_gui(f"Ошибка подключения к Telegram: {e}")
                self.telegram_monitoring_active = False
                self.put_message_in_queue(('set_monitoring_status', False)) # Обновление кнопки GUI
                if self.telethon_client and self.telethon_client.is_connected():
                    await self.telethon_client.disconnect()
                self.telethon_client = None

        self.run_async_task(_start_client())

    def stop_telegram_monitoring(self):
        """Останавливает мониторинг Telegram."""
        if not self.telegram_monitoring_active or not self.telethon_client:
            self.log_to_gui("Мониторинг Telegram не запущен.")
            return

        async def _stop_client():
            try:
                if self.telethon_client.is_connected():
                    await self.telethon_client.disconnect()
                logging.info("Клиент Telegram отключен.")
                self.log_to_gui("Мониторинг Telegram остановлен.")
            except Exception as e:
                logging.exception("Ошибка при остановке Telegram клиента:")
                self.log_to_gui(f"Ошибка отключения от Telegram: {e}")
            finally:
                self.telethon_client = None
                self.telegram_monitoring_active = False
                self.put_message_in_queue(('set_monitoring_status', False)) # Обновление кнопки GUI

        future = self.run_async_task(_stop_client())
        if future:
            try:
                future.result(timeout=10) # Ждем завершения асинхронной задачи
            except asyncio.TimeoutError:
                logging.warning("Остановка клиента Telegram заняла слишком много времени.")
            except Exception as e:
                logging.error(f"Исключение при ожидании остановки клиента Telegram: {e}")


    async def _handle_telegram_message(self, event):
        """Обработчик новых сообщений из Telethon (выполняется в asyncio потоке)."""
        message_text = event.message.message
        logging.info(f"Получено сообщение Telegram: {message_text[:100]}...") # Логируем начало сообщения
        self.put_message_in_queue(('log', f"TG: {message_text}"))

        # Парсинг сообщения (пример, ваша реализация может отличаться)
        try:
            parsed_data = parse_message(message_text) # Эта функция должна быть быстрой
            if parsed_data and 'token_address' in parsed_data:
                token_address = parsed_data['token_address']
                signal_type = parsed_data.get('signal_type', 'Уверенный') # или 'default'
                self.log_to_gui(f"Обнаружен сигнал: {signal_type} для токена {token_address}")

                # Получаем сумму из настроек для данного типа сигнала
                amount_sol = self.settings_tab.get_signal_amount(signal_type)
                
                # Запускаем своп в отдельном потоке, чтобы не блокировать asyncio
                self.trigger_swap_async(input_mint="SOL", output_mint=token_address, amount=amount_sol)

        except Exception as e:
            logging.exception("Ошибка парсинга сообщения Telegram:")
            self.put_message_in_queue(('log', f"Ошибка парсинга: {e}"))


    def start_profit_monitoring(self):
        """Запускает мониторинг прибыли в отдельном потоке."""
        if self.profit_monitoring_active:
            self.log_to_gui("Мониторинг прибыли уже запущен.")
            return

        self.profit_monitor_stop_event.clear()
        # Передаем очередь и событие остановки в задачу
        self.profit_monitor_thread = threading.Thread(
            target=profit_monitoring_task,
            args=(self.config, self.gui_queue, self.profit_monitor_stop_event, self.settings_tab.get_profit_target, self.is_demo_mode), # Передаем функции для получения настроек
            daemon=True # Поток завершится, если основной поток завершится
        )
        self.profit_monitor_thread.start()
        self.profit_monitoring_active = True
        self.log_to_gui("Мониторинг прибыли запущен.")
        # Здесь можно обновить статус кнопки в GUI через очередь, если она есть

    def stop_profit_monitoring(self):
        """Останавливает мониторинг прибыли."""
        if not self.profit_monitoring_active or not self.profit_monitor_thread:
            self.log_to_gui("Мониторинг прибыли не запущен.")
            return

        self.profit_monitor_stop_event.set() # Сигнализируем потоку о необходимости остановки
        # Не ждем join(), так как поток daemon=True, он завершится сам.
        # Если нужен join, убедитесь, что profit_monitoring_task корректно завершается.
        # self.profit_monitor_thread.join(timeout=5) # Опционально, с таймаутом

        self.profit_monitoring_active = False
        # Поток может еще работать короткое время после set(),
        # но новых задач выполнять не будет.
        logging.info("Сигнал остановки отправлен потоку мониторинга прибыли.")
        self.log_to_gui("Мониторинг прибыли остановлен.")
         # Здесь можно обновить статус кнопки в GUI через очередь, если она есть

    def execute_swap_from_gui(self):
        """Выполняет своп на основе данных из GUI в отдельном потоке."""
        input_mint = self.main_tab.input_mint_entry.get()
        output_mint = self.main_tab.output_mint_entry.get()
        amount_str = self.main_tab.amount_entry.get()

        if not all([input_mint, output_mint, amount_str]):
            messagebox.showerror("Ошибка", "Заполните все поля для свопа.")
            return
        try:
            amount = float(amount_str)
        except ValueError:
            messagebox.showerror("Ошибка", "Сумма должна быть числом.")
            return

        # Блокируем кнопки на время выполнения
        self.main_tab.set_swap_buttons_state(tk.DISABLED)
        # Запускаем своп в потоке
        self.trigger_swap_async(input_mint, output_mint, amount, manual=True)

    def swap_from_clipboard(self):
         """Выполняет своп на основе адреса из буфера обмена."""
         try:
            token_address = self.root.clipboard_get()
            # Простейшая валидация адреса Solana (можно улучшить)
            if len(token_address) < 32 or len(token_address) > 45: 
                raise ValueError("Не похоже на адрес токена Solana в буфере обмена.")
            
            # Используем настройки по умолчанию или из конфига
            # Например, всегда покупаем за SOL на сумму "Рискованного" сигнала
            amount = self.settings_tab.get_signal_amount("Рискованный") 
            input_mint = "SOL" 
            output_mint = token_address

            self.log_to_gui(f"Запуск свопа из буфера: SOL -> {output_mint} ({amount} SOL)")
            self.main_tab.set_swap_buttons_state(tk.DISABLED)
            self.trigger_swap_async(input_mint, output_mint, amount, manual=True)

         except tk.TclError:
             messagebox.showerror("Ошибка", "Буфер обмена пуст или содержит не текст.")
         except ValueError as e:
             messagebox.showerror("Ошибка", str(e))
         except Exception as e:
             logging.exception("Ошибка при свопе из буфера обмена:")
             messagebox.showerror("Ошибка", f"Непредвиденная ошибка: {e}")
             self.main_tab.set_swap_buttons_state(tk.NORMAL) # Разблокировать в случае ошибки инициации


    def trigger_swap_async(self, input_mint, output_mint, amount, manual=False):
        """Запускает выполнение функции swap_tokens в отдельном потоке."""
        
        # Проверка, не выполняется ли уже своп (если нужно ограничение)
        # if not self.swap_lock.acquire(blocking=False):
        #     self.log_to_gui("Другой своп уже выполняется.")
        #     if manual: # Если запуск ручной, разблокируем кнопки
        #          self.put_message_in_queue(('set_swap_buttons_state', tk.NORMAL))
        #     return
        
        # Используем блокировку, если она нужна
        # self.swap_lock.acquire() 

        thread = threading.Thread(
            target=self._swap_worker,
            args=(input_mint, output_mint, amount, manual),
            daemon=True
        )
        thread.start()

    def _swap_worker(self, input_mint, output_mint, amount, manual):
        """Worker функция, выполняющаяся в потоке для свопа."""
        try:
            demo_mode = self.is_demo_mode()
            self.log_to_gui(f"Начинаю своп ({'Демо' if demo_mode else 'Реал'}): {amount} {input_mint} -> {output_mint}")

            # Вызываем вашу функцию свопа
            # Она должна возвращать результат (например, строку с сообщением)
            # и не должна напрямую обновлять GUI
            result_message = swap_tokens(
                input_mint, 
                output_mint, 
                amount, 
                demo_mode=demo_mode,
                config=self.config, # Передаем конфиг, если он нужен для API ключей и т.д.
                # wallet=self.wallet_instance # Передаем экземпляр кошелька, если нужно
            )
            
            log_msg = f"Своп завершен: {result_message}"
            logging.info(log_msg)
            self.put_message_in_queue(('log', log_msg))
            # После успешного свопа обновляем портфель
            self.update_portfolio_display() 

        except Exception as e:
            log_msg = f"Ошибка во время свопа: {e}"
            logging.exception("Ошибка выполнения свопа:")
            self.put_message_in_queue(('log', log_msg))
            # Можно добавить вывод в messagebox для ручных свопов
            if manual:
                self.put_message_in_queue(('show_error', 'Ошибка свопа', f'{e}'))

        finally:
            # Разблокируем кнопки GUI, если своп был ручной
            if manual:
                 self.put_message_in_queue(('set_swap_buttons_state', tk.NORMAL))
            # Освобождаем блокировку, если использовали
            # self.swap_lock.release() 

    def update_portfolio_display(self):
         """Запускает обновление данных портфеля в отдельном потоке."""
         # Можно добавить проверку, не идет ли уже обновление
         thread = threading.Thread(target=self._update_portfolio_worker, daemon=True)
         thread.start()

    def _update_portfolio_worker(self):
        """Получает данные портфеля и отправляет их в GUI."""
        try:
            demo_mode = self.is_demo_mode()
            # Эта функция должна получать данные кошелька/портфеля
            # (баланс SOL, список токенов с количеством и ценой покупки)
            # Она не должна зависеть от GUI
            portfolio_data = self._get_portfolio_data(demo_mode) 
            
            # Отправляем данные в очередь для обновления GUI
            self.put_message_in_queue(('update_portfolio', portfolio_data))
            
        except Exception as e:
            logging.exception("Ошибка при обновлении данных портфеля:")
            self.put_message_in_queue(('log', f"Ошибка обновления портфеля: {e}"))
            
    def _get_portfolio_data(self, demo_mode):
        """Заглушка: Замените реальной логикой получения данных портфеля."""
        # В реальном приложении здесь будет логика получения баланса SOL
        # и списка токенов (возможно, из trading.wallet или trading.monitor)
        if demo_mode:
            # Пример для демо-режима
             sol_balance = DEMO_WALLET['SOL']
             tokens = DEMO_WALLET['tokens'] # Словарь {addr: {'amount': X, 'purchase_price': Y}}
             # Здесь нужно получить текущие цены для расчета стоимости и прибыли
             # current_prices = get_current_prices(tokens.keys()) # Ваша функция API
             # и рассчитать total_value, profit по каждому токену
             # пока возвращаем заглушку
             processed_tokens = [{'address': addr, 'amount': data['amount'], 'price': 0, 'value': 0, 'profit': '0.00x'} 
                                for addr, data in tokens.items()]
             return {'sol_balance': sol_balance, 'tokens': processed_tokens}
        else:
            # Реальная логика для получения баланса и токенов с блокчейна/API
             logging.warning("Логика получения реального портфеля не реализована")
             return {'sol_balance': 0.0, 'tokens': []}


    def reset_demo_wallet(self):
        """Сбрасывает демо-кошелек (пример)."""
        # Эта функция должна безопасно обновить DEMO_WALLET
        # Возможно, потребуется блокировка, если другие потоки его читают/пишут
        global DEMO_WALLET
        logging.info("Сброс демо-кошелька.")
        # Нужна реализация безопасного сброса, возможно, через wallet.py
        # wallet.reset_demo()
        DEMO_WALLET = {'SOL': 10.0, 'tokens': {}} # Пример простого сброса
        self.log_to_gui("Демо-кошелек сброшен.")
        self.update_portfolio_display() # Обновляем отображение

    def process_gui_queue(self):
        """Обрабатывает сообщения из очереди и обновляет GUI."""
        try:
            while True: # Обрабатываем все сообщения в очереди за раз
                message = self.gui_queue.get_nowait()

                msg_type = message[0]
                payload = message[1] if len(message) > 1 else None
                # payload2 = message[2] if len(message) > 2 else None # Для сообщений с >1 аргументом

                if msg_type == 'log':
                    self.main_tab.update_log(payload)
                elif msg_type == 'update_portfolio':
                    self.portfolio_tab.update_portfolio(payload) # payload = portfolio_data
                elif msg_type == 'set_monitoring_status':
                     self.main_tab.update_monitoring_button_state(payload) # payload = True/False
                elif msg_type == 'set_swap_buttons_state':
                     self.main_tab.set_swap_buttons_state(payload) # payload = tk.NORMAL/tk.DISABLED
                elif msg_type == 'show_error':
                     # payload должен быть кортежем (title, message)
                     if isinstance(payload, (list, tuple)) and len(payload) == 2:
                         messagebox.showerror(payload[0], payload[1])
                     else:
                         messagebox.showerror("Ошибка", str(payload))
                # Добавьте другие типы сообщений по мере необходимости

        except queue.Empty:
            # Очередь пуста, ничего не делаем
            pass
        except Exception as e:
            logging.exception("Ошибка в обработчике очереди GUI:")

        # Перезапускаем таймер для следующей проверки очереди
        self.root.after(100, self.process_gui_queue)

    def put_message_in_queue(self, message):
        """Потокобезопасно добавляет сообщение в очередь GUI."""
        self.gui_queue.put(message)

    def log_to_gui(self, message):
        """Удобная функция для отправки лог-сообщения в GUI."""
        self.put_message_in_queue(('log', message))

    def is_demo_mode(self):
        """Возвращает текущий режим работы (Демо/Реал)."""
        # Предполагается, что у MainTab есть метод для получения режима
        return self.main_tab.get_mode() == "Демо"

    def on_closing(self):
        """Выполняется при закрытии окна."""
        logging.info("Запрос на закрытие приложения...")
        if messagebox.askokcancel("Выход", "Вы уверены, что хотите выйти?"):
            # 1. Остановить мониторинг прибыли
            self.stop_profit_monitoring()

            # 2. Остановить мониторинг Telegram
            # Остановка Telethon может занять время, делаем это синхронно насколько возможно
            if self.telegram_monitoring_active and self.telethon_client:
                 logging.info("Начинаю остановку клиента Telegram...")
                 future = self.run_async_task(self.telethon_client.disconnect())
                 if future:
                     try:
                        future.result(timeout=5) # Даем 5 секунд на отключение
                        logging.info("Клиент Telegram успешно отключен.")
                     except asyncio.TimeoutError:
                        logging.warning("Таймаут при отключении клиента Telegram.")
                     except Exception as e:
                        logging.error(f"Ошибка при отключении Telegram: {e}")
                 else:
                     logging.warning("Не удалось запланировать отключение Telegram.")
                 self.telegram_monitoring_active = False # Устанавливаем флаг

            # 3. Остановить цикл asyncio
            if self.asyncio_loop.is_running():
                logging.info("Отправка сигнала остановки в asyncio loop...")
                self.asyncio_loop.call_soon_threadsafe(self.asyncio_loop.stop)

            # 4. Дождаться завершения потока asyncio (опционально, если не daemon)
            # if self.telegram_thread and self.telegram_thread.is_alive():
            #     logging.info("Ожидание завершения потока asyncio...")
            #     self.telegram_thread.join(timeout=5)
            #     if self.telegram_thread.is_alive():
            #         logging.warning("Поток asyncio не завершился.")


            # 5. Дождаться завершения потока мониторинга прибыли (если не daemon или нужен join)
            # if self.profit_monitor_thread and self.profit_monitor_thread.is_alive():
            #     logging.info("Ожидание завершения потока мониторинга прибыли...")
            #     self.profit_monitor_thread.join(timeout=5) # Ждем завершения
            #     if self.profit_monitor_thread.is_alive():
            #         logging.warning("Поток мониторинга прибыли не завершился.")


            # 6. Закрыть окно Tkinter
            logging.info("Закрытие окна приложения.")
            self.root.destroy()

# --- Точка входа ---
if __name__ == "__main__":
    main_root = tk.Tk()
    app = TradingBotApp(main_root)
    main_root.mainloop()
